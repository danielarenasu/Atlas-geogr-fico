
export interface Country {
  name: string;
  capital: string;
  isoCode: string;
  continent: string;
  area: string;
}

export interface Continent {
  name: string;
  description: string;
  countriesCount: number;
  area: string;
  colorClass: string;
}

export interface Ocean {
  name: string;
  size: string;
  location: string;
  description: string;
}

export interface Language {
  name: string;
  origin: string;
  speakers: string;
  locations: string[];
}

export interface GlossaryTerm {
  term: string;
  definition: string;
  example?: string;
}

export interface Message {
  role: 'user' | 'model';
  text: string;
}
