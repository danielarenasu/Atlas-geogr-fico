
import React, { useState, useRef, useEffect } from 'react';
import { Message } from '../types';
import { geminiService } from '../services/geminiService';

const RobotsAnim: React.FC = () => (
  <div className="flex items-end gap-1 mb-2 mr-3 pointer-events-none drop-shadow-xl scale-90 md:scale-100 origin-bottom-right">
    {/* C-3PO Full Body SVG */}
    <div className="animate-bounce" style={{ animationDuration: '3.5s' }}>
      <svg width="40" height="80" viewBox="0 0 40 80">
        <circle cx="20" cy="15" r="8" fill="#D4AF37" stroke="#996515" strokeWidth="1" />
        <rect x="12" cy="25" width="16" height="25" rx="4" fill="#D4AF37" stroke="#996515" strokeWidth="1" />
        <line x1="12" y1="30" x2="5" y2="45" stroke="#D4AF37" strokeWidth="3" />
        <line x1="28" y1="30" x2="35" y2="45" stroke="#D4AF37" strokeWidth="3" />
        <rect x="13" cy="52" width="6" height="25" fill="#D4AF37" stroke="#996515" />
        <rect x="21" cy="52" width="6" height="25" fill="#D4AF37" stroke="#996515" />
      </svg>
    </div>
    {/* R2-D2 Full Body SVG */}
    <div className="animate-bounce" style={{ animationDuration: '3s', animationDelay: '0.4s' }}>
      <svg width="35" height="55" viewBox="0 0 40 60">
        <path d="M10 20 Q20 5 30 20 Z" fill="#E2E8F0" stroke="#1E40AF" strokeWidth="1" />
        <rect x="10" cy="20" width="20" height="25" fill="#F8FAFC" stroke="#1E40AF" />
        <rect x="5" cy="25" width="5" height="30" fill="#E2E8F0" />
        <rect x="30" cy="25" width="5" height="30" fill="#E2E8F0" />
      </svg>
    </div>
  </div>
);

const ChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: "¡Hola! Soy tu asistente de geografía de Conoce tu mundo. ¿Deseas que resolvamos alguna duda sobre países o curiosidades territoriales?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);
    const aiResponse = await geminiService.askDaniel(userMsg);
    setMessages(prev => [...prev, { role: 'model', text: aiResponse }]);
    setIsLoading(false);
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col items-end">
      {!isOpen && <RobotsAnim />}

      {isOpen && (
        <div className="w-64 md:w-[320px] h-[450px] bg-white rounded-[2.5rem] shadow-2xl border border-emerald-100 flex flex-col mb-4 overflow-hidden animate-in zoom-in duration-300">
          <div className="bg-emerald-600 p-5 flex justify-between items-center text-white">
            <div className="flex items-center gap-3">
              <span className="text-xl">🤖</span>
              <div className="leading-none">
                <p className="font-black text-[10px] uppercase tracking-widest">Chat Conoce tu mundo</p>
                <p className="text-[7px] text-emerald-100 font-bold uppercase">Geografía 2025</p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-emerald-700 p-2 rounded-xl text-xs transition-colors">✕</button>
          </div>

          <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-slate-50 custom-scrollbar">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[90%] p-3 rounded-2xl text-[11px] shadow-sm leading-snug ${
                  msg.role === 'user' ? 'bg-emerald-600 text-white rounded-tr-none' : 'bg-white text-slate-800 rounded-tl-none border border-slate-100'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-4 border-t border-emerald-50 flex gap-2 bg-white">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Escribe aquí..."
              className="flex-1 bg-slate-100 border-none rounded-xl py-2 px-4 text-[11px] outline-none focus:ring-1 focus:ring-emerald-500 transition-all"
            />
            <button onClick={handleSend} disabled={isLoading} className="bg-emerald-600 text-white w-9 h-9 rounded-lg shadow-lg flex items-center justify-center hover:bg-emerald-700 transition-colors">➤</button>
          </div>
        </div>
      )}

      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-emerald-600 text-white w-12 h-12 rounded-full shadow-2xl hover:scale-105 transition-transform flex items-center justify-center border-2 border-white"
      >
        <span className="text-xl">🌍</span>
      </button>
    </div>
  );
};

export default ChatBot;
