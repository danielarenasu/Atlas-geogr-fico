
import React, { useState } from 'react';
import Section from './components/Section';
import ChatBot from './components/ChatBot';
import ColumbusGuide from './components/ColumbusGuide';
import FootprintTrail from './components/FootprintTrail';
import ContinentCard from './components/ContinentCard';
import GlobeModal from './components/GlobeModal';
import { CONTINENTS, COUNTRIES, OCEANS, GLOSSARY } from './constants';

const App: React.FC = () => {
  const [isMapOpen, setIsMapOpen] = useState(false);
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [showComingSoon, setShowComingSoon] = useState(false);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80; // Compensación por la barra de navegación fija
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const triggerComingSoon = () => {
    setShowComingSoon(true);
    setTimeout(() => setShowComingSoon(false), 3000);
  };

  return (
    <div className="min-h-screen bg-slate-50 selection:bg-emerald-100 selection:text-emerald-900 overflow-x-hidden relative">
      
      {/* Estela de exploración (Huellas) - z-0 */}
      <FootprintTrail />

      {/* Elementos Decorativos Dinámicos - z-[-1] */}
      <div className="absolute inset-0 pointer-events-none -z-1 overflow-hidden">
        <div className="absolute top-[100px] left-[5%] text-6xl opacity-20 animate-bounce">🌍</div>
        <div className="absolute top-[1500px] right-[8%] text-5xl opacity-20 animate-pulse">🦒</div>
        <div className="absolute top-[3000px] left-[7%] text-4xl opacity-20 animate-spin-slow">🚢</div>
        <div className="absolute top-[4500px] right-[10%] text-6xl opacity-20">🕌</div>
        <div className="absolute top-[6000px] left-[45%] text-5xl opacity-20">🏔️</div>
      </div>

      {/* Navegación - z-40 */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-md border-b border-slate-100 z-40">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <span className="text-xl font-black tracking-tighter text-emerald-600 flex items-center gap-2">
            <span className="text-2xl">🌏</span> CONOCE TU MUNDO
          </span>
          <div className="hidden md:flex items-center space-x-8">
            <button onClick={scrollToTop} className="text-sm font-bold text-slate-500 hover:text-emerald-600 transition-colors uppercase tracking-widest outline-none">INICIO</button>
            <span className="text-sm font-bold text-slate-300 uppercase tracking-widest cursor-default">GEOGRAFÍA</span>
            <button onClick={triggerComingSoon} className="text-sm font-bold text-slate-500 hover:text-emerald-600 transition-colors uppercase tracking-widest outline-none">ZONAS HORARIAS</button>
            <button onClick={() => setIsProjectModalOpen(true)} className="text-sm font-bold text-slate-500 hover:text-emerald-600 transition-colors uppercase tracking-widest outline-none">PROYECTO</button>
          </div>
          <button 
            onClick={() => setIsMapOpen(true)}
            className="bg-emerald-500 text-white px-6 py-2.5 rounded-full text-sm font-black hover:bg-emerald-600 hover:shadow-xl hover:shadow-emerald-100 active:scale-95 transition-all flex items-center gap-2"
          >
            MAPA GLOBAL
          </button>
        </div>
      </nav>

      {/* Hero Section - z-10 para tapar huellas */}
      <header id="inicio" className="pt-48 pb-32 px-6 relative z-10 overflow-hidden bg-emerald-600">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
        <div className="absolute -bottom-24 -right-24 w-[40rem] h-[40rem] bg-emerald-400 rounded-full blur-[120px] -z-0 opacity-30"></div>
        
        <div className="max-w-7xl mx-auto flex flex-col items-center text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-5 py-2 mb-10 text-[10px] font-black tracking-[0.3em] text-emerald-100 uppercase bg-emerald-700/50 backdrop-blur rounded-full border border-emerald-400/30 shadow-sm">
            Exploración • Pasión Geográfica • 2025
          </div>
          <h1 className="text-7xl md:text-9xl font-black text-white mb-10 tracking-tighter leading-[0.85] uppercase drop-shadow-2xl">
            Atlas <br/> <span className="text-emerald-200">Universal</span>
          </h1>
          <p className="text-xl md:text-3xl text-emerald-50 max-w-4xl mb-14 font-light leading-relaxed">
            Un compendio completo creado para <span className="text-white font-bold">conocer tu mundo</span> y a todos los apasionados de la Geografía. Datos precisos, capitales y fronteras actualizadas.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-8">
            <button 
              onClick={() => scrollToSection('explorar')}
              className="bg-white text-emerald-600 px-12 py-6 rounded-2xl font-black text-lg shadow-2xl flex items-center justify-center gap-3 transition-transform hover:scale-105 active:scale-95"
            >
              EXPLORAR NACIONES 🗺️
            </button>
            <button 
              onClick={() => setIsMapOpen(true)}
              className="bg-emerald-700 text-white border-2 border-emerald-500 px-12 py-6 rounded-2xl font-black hover:bg-emerald-800 transition-all text-lg"
            >
              VISOR 3D
            </button>
          </div>
        </div>
      </header>

      {/* Atlas Sections - Tienen z-10 internamente */}
      <Section id="explorar" title="Atlas por Continente" subtitle="La riqueza natural y territorial del planeta curada minuciosamente para que puedas conocer tu mundo.">
        <div className="grid grid-cols-1 gap-12">
          {CONTINENTS.map((cont) => (
            <ContinentCard 
              key={cont.name} 
              continent={cont} 
              countries={COUNTRIES.filter(c => c.continent === cont.name)} 
            />
          ))}
        </div>
      </Section>

      <Section id="oceanos" title="Océanos del Mundo" subtitle="Las grandes masas de agua salada de nuestro planeta.">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {OCEANS.map((ocean) => (
            <div key={ocean.name} className="bg-white border border-slate-100 p-8 rounded-[2.5rem] hover:shadow-2xl transition-all shadow-sm relative">
              <div className="text-4xl mb-6">🌊</div>
              <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tighter mb-4">{ocean.name}</h3>
              <p className="text-sm font-black text-emerald-600 uppercase tracking-widest mb-4">{ocean.size}</p>
              <p className="text-slate-500 text-sm leading-relaxed">{ocean.description}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section id="glosario" title="Glosario Geográfico" subtitle="Conceptos fundamentales explicados con ejemplos precisos.">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {GLOSSARY.map((item) => (
            <div key={item.term} className="p-8 bg-white border border-slate-200 rounded-[2.5rem] hover:border-emerald-500 transition-all shadow-sm">
              <dt className="text-xl font-black text-emerald-600 uppercase tracking-widest mb-3">{item.term}</dt>
              <dd className="text-sm text-slate-600 leading-relaxed">
                <p className="mb-4">{item.definition}</p>
                {item.example && (
                  <div className="p-4 bg-emerald-50 rounded-2xl border-l-4 border-emerald-500">
                    <span className="text-emerald-800 font-bold italic text-sm">Ejemplo: {item.example}</span>
                  </div>
                )}
              </dd>
            </div>
          ))}
        </div>
      </Section>

      {/* Notificación Próximamente */}
      <div className={`fixed bottom-24 right-1/2 translate-x-1/2 z-[70] transition-all duration-500 transform ${showComingSoon ? 'translate-y-0 opacity-100' : 'translate-y-12 opacity-0'}`}>
        <div className="bg-slate-900 text-white px-8 py-4 rounded-full shadow-2xl font-black text-sm tracking-widest flex items-center gap-3">
          <span className="text-xl">⏳</span> PRÓXIMAMENTE
        </div>
      </div>

      {/* Footer - z-10 para tapar huellas */}
      <footer className="py-24 bg-slate-900 text-white relative z-10">
        <div className="max-w-7xl mx-auto px-6 flex flex-col items-center text-center">
          <span className="text-3xl font-black text-emerald-400 mb-10 tracking-tighter flex items-center gap-3">
             <span className="text-4xl">🌍</span> CONOCE TU MUNDO
          </span>
          <div className="flex flex-wrap justify-center gap-x-12 gap-y-6 mb-16 font-bold text-slate-400 text-xs uppercase tracking-[0.3em]">
            <button onClick={scrollToTop} className="hover:text-emerald-400 outline-none">INICIO</button>
            <button onClick={triggerComingSoon} className="hover:text-emerald-400 outline-none">ZONAS HORARIAS</button>
            <button onClick={() => setIsProjectModalOpen(true)} className="hover:text-emerald-400 outline-none">PROYECTO</button>
            <button onClick={() => scrollToSection('glosario')} className="hover:text-emerald-400 outline-none">GLOSARIO</button>
          </div>
          <div className="w-full h-px bg-slate-800 mb-10"></div>
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.5em]">© 2025 • ATLAS GEOGRÁFICO CONOCE TU MUNDO • ACTUALIZACIÓN PERMANENTE</p>
        </div>
      </footer>

      <ColumbusGuide />
      <ChatBot />
      <GlobeModal isOpen={isMapOpen} onClose={() => setIsMapOpen(false)} />
      
      {isProjectModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm" onClick={() => setIsProjectModalOpen(false)}></div>
          <div className="relative w-full max-w-lg bg-white rounded-[3rem] p-12 shadow-2xl">
            <h3 className="text-3xl font-black text-slate-900 mb-6 uppercase tracking-tight text-center">Conoce Tu Mundo 2025</h3>
            <p className="text-slate-600 leading-relaxed mb-8 text-center italic">
              "Nuestra misión es compartir la pasión por la geografía, uniendo datos precisos con un diseño que celebre la belleza de nuestro mundo."
            </p>
            <button 
              onClick={() => setIsProjectModalOpen(false)}
              className="w-full bg-emerald-500 text-white font-black py-5 rounded-2xl hover:bg-emerald-600 shadow-xl"
            >
              ¡CONTINUAR!
            </button>
          </div>
        </div>
      )}
      
      <style>{`
        .animate-spin-slow { animation: spin 20s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
};

export default App;
