
import { GoogleGenAI } from "@google/genai";
import { BIO_CONTEXT } from "../constants";

export class GeminiService {
  private ai: GoogleGenAI;
  private modelName = 'gemini-3-flash-preview';

  constructor() {
    // Fixed initialization to use named parameter and process.env.API_KEY directly
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async askDaniel(question: string) {
    try {
      // Use ai.models.generateContent directly with model name
      const response = await this.ai.models.generateContent({
        model: this.modelName,
        contents: question,
        config: {
          systemInstruction: BIO_CONTEXT,
          temperature: 0.7,
        },
      });

      // text is a property, not a method
      return response.text || "Lo siento, no pude procesar tu duda geográfica ahora.";
    } catch (error) {
      console.error("Gemini API Error:", error);
      return "¡Ups! Mi mapa mental se desactualizó un momento. ¿Podrías repetir la pregunta?";
    }
  }
}

export const geminiService = new GeminiService();
